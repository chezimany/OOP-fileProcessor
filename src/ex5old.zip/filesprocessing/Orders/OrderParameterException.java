package filesprocessing.Orders;

import filesprocessing.Type1Error;

public class OrderParameterException extends Type1Error {
    public OrderParameterException() {
        super();
    }
}
