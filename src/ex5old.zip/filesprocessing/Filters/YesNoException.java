package filesprocessing.Filters;

import filesprocessing.Type1Error;

public class YesNoException extends FilterException {
    private static final long serialVersionUID = 1L;

    public YesNoException() {
        super();
    }
}
