package filesprocessing.Filters;

import filesprocessing.Type1Error;

public class FilterException extends Type1Error {
    private static final long serialVersionUID = 1L;

    public FilterException() {
        super();
    }
}
