package filesprocessing;

public class Type1Error extends Exception {
    private static final long serialVersionUID = 1L;

    public Type1Error(){
        super();
    }

    public Type1Error(String s){
        super(s);
    }

}
