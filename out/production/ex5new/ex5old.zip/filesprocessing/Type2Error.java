package filesprocessing;

public class Type2Error extends Exception {
    private static final long serialVersionUID = 1L;

    public Type2Error() {
        super();
    }

    public Type2Error(String s) {
        super(s);
    }
}
