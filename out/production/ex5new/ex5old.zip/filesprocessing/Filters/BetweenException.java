package filesprocessing.Filters;

import filesprocessing.Type1Error;

public class BetweenException extends FilterException {
    private static final long serialVersionUID = 1L;

    public BetweenException(){
        super();
    }
}
