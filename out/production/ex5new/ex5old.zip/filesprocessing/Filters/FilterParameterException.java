package filesprocessing.Filters;

import filesprocessing.Type1Error;

public class FilterParameterException extends FilterException {
    private static final long serialVersionUID = 1L;
    public FilterParameterException() {
        super();
    }
}
