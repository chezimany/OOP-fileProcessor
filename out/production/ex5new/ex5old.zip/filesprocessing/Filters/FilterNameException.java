package filesprocessing.Filters;

import filesprocessing.Type1Error;

public class FilterNameException extends FilterException {
    private static final long serialVersionUID = 1L;
    public FilterNameException(){
        super();
    }
}
