package filesprocessing.Filters;

import filesprocessing.Type1Error;

public class NegativeBoundException extends FilterException {
    private static final long serialVersionUID = 1L;

    public NegativeBoundException() {
        super();
    }
}
