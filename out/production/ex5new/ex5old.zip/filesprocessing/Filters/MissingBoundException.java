package filesprocessing.Filters;

import filesprocessing.Type1Error;

public class MissingBoundException extends FilterException {
    private static final long serialVersionUID = 1L;
    public MissingBoundException() {
        super();
    }
}
